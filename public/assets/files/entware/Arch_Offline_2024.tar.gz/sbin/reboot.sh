#!/bin/sh

ndmc -c system reboot
