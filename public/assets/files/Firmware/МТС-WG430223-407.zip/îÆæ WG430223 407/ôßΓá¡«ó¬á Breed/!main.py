﻿import telnetlib
import re
import tftpy
import sys
import socket
import gateway

router_ip_address=gateway.get_ip_address()
	
try:
	print ("")	
	telnet = telnetlib.Telnet(router_ip_address)
except:
	print ("---------------------------------")
	print ("!!! Telnet роутера не запущен !!!")
	print ("---------------------------------")
	print ("")
	print ("Версия стоковой прошивки в вашем роутере должна быть 2.00.18")
	print ("")
	print ("1: Понизьте версию, файл прошивки (MTC_2.00.18.bin) в папке data.")
	print ("2: Запустите заного данный скрипт")
	print ("")
	sys.exit(1)

from multiprocessing import Process

my_ip = bytes(socket.gethostbyname(socket.gethostname()), encoding='ascii')   # my_ip присваивается ip адрес компа
def tftp_server():
    tftpServer = tftpy.TftpServer('data')
    tftpServer.listen(my_ip, 2048)

def main():
    telnet.read_until(b'login:')
    telnet.write((b'admin\n'))
    telnet.read_until(b'password:')
    telnet.write((b'admin\n'))
    telnet.read_until(b'~ #')

    telnet.write(b'(ifconfig eth3 | grep -E -o "[0-9,aAbBcCdDeEfF]{1,2}(\:[0-9,aAbBcCdDeEfF;]{1,3}){5}" | sed s/://g)\n')

    string = telnet.read_until(b'~ #').decode('ascii')
    mac = re.search(r'([A-F\d]{12})', string).group(0)
    mac1 = ':'.join(mac[i:i + 2] for i in range(0, len(mac), 2))
    print ("")
    print (("Ваш MAC-адрес: ") + mac1)
    msg = mac.encode('ascii') + b'.bin'
    telnet.write((b'dd if=/dev/mtd3 of=/tmp/') + (msg) + (b' count=512\n'))
    telnet.read_until(b'~ #')
    print ("")
    print (("eeprom Вашего роутера ") + mac + (".bin считался успешно в папку data."))
    print ("")
    telnet.write(b'cd /tmp\n')
    telnet.read_until(b'/tmp #')
    telnet.write((b'tftp -l ') + (msg) + (b' -p ') + (my_ip) + (b':2048\n'))
    telnet.read_until(b'/tmp #')
    telnet.write((b'tftp -g -r uboot_x_breed.bin ') +  (my_ip) + (b':2048\n'))
    telnet.read_until(b'/tmp #')
    telnet.write(b"dd if=/tmp/uboot_x_breed.bin of=/dev/mtdblock1\n")
    telnet.read_until(b'/tmp #')
    telnet.write((b'tftp -l ') + (msg) + (b' -p ') + (my_ip) + (b':2048\n'))
    telnet.read_until(b'/tmp #')
    telnet.write(b"reboot\n")
    telnet.read_until(b'/tmp #')
    print ("Запись загрузчика Breed завершена.")
    print ("")
    print ("---------------------------------------------------------------------")
    print ("")
    print ("Роутер перезапускается в загрузчик Breed, ждите 10 секунд.")
    print ("")
    print ("Заходим в браузере по адрессу 192.168.1.1")
    print ("")
    print ("https://t.me/keen_prt")
    print ("---------------------------------------------------------------------")
    print ("")
    telnet.close()

if __name__ == '__main__':
    p = Process(target=tftp_server)
    p.start()
    main()
    p.terminate()
    sys.exit()