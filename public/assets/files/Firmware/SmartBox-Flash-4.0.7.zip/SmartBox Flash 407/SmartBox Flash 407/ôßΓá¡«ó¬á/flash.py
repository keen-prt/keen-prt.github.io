﻿import os, stat
import shutil
import telnetlib
import re
import tftpy
import sys
import socket
import gateway

router_ip_address=gateway.get_ip_address()
	
try:
	print ("")	
	telnet = telnetlib.Telnet(router_ip_address)
except:
	print ("---------------------------------")
	print ("!!! Telnet роутера не запущен !!!")
	print ("---------------------------------")
	print ("")
	print ("Версия стоковой прошивки в вашем роутере должна быть ниже 1.00.16")
	print ("")
	print ("1: Понизьте версию, файл прошивки (SmartBoxFlash_1.00.15.trx) в папке data.")
	print ("2: После обязательно сделайте сброс на заводские настройки.")
	print ("3: Запустите заново данный скрипт")
	print ("")
	sys.exit(1)

from multiprocessing import Process

my_ip = bytes(socket.gethostbyname(socket.gethostname()), encoding='ascii')

def tftp_server():
tftpServer = tftpy.TftpServer('data')
tftpServer.listen(my_ip, 2048)

def main():

telnet.read_until(b'~ #')

telnet.write(b'(ifconfig eth2 | grep -E -o "[0-9,aAbBcCdDeEfF]{1,2}(\:[0-9,aAbBcCdDeEfF;]{1,3}){5}" | sed s/://g)\n')

string = telnet.read_until(b'~ #').decode('ascii')
mac = re.search(r'([A-F\d]{12})', string).group(0)
mac1 = ':'.join(mac[i:i + 2] for i in range(0, len(mac), 2))
print ("")
print (("Ваш MAC-адрес: ") + mac1)
msg = mac.encode('ascii') + b'.bin'
telnet.write((b'dd if=/dev/mtd3 of=/tmp/') + (msg) + (b' count=512\n'))
telnet.read_until(b'~ #')

print ("")
print (("eeprom Вашего роутера ") + mac + (".bin считался успешно в папку /data."))
print ("Сохраните его если планируете возврат на стоковую прошивку.")
print ("")

telnet.write(b'cd /tmp\n')
telnet.read_until(b'/tmp #')

telnet.write((b'tftp -l ') + (msg) + (b' -p ') + (my_ip) + (b':2048\n'))
telnet.read_until(b'/tmp #')

telnet.write((b'tftp -g -r bootloader.bin ') +  (my_ip) + (b':2048\n'))
telnet.read_until(b'/tmp #')

telnet.write(b"dd if=/tmp/bootloader.bin of=/dev/mtdblock1\n")
telnet.read_until(b'/tmp #')

telnet.write((b'tftp -l ') + (msg) + (b' -p ') + (my_ip) + (b':2048\n'))
telnet.read_until(b'/tmp #')

print ("Запись загрузчика завершена.")
print ("")

telnet.write(b"reboot\n")
telnet.read_until(b'/tmp #')

shutil.copy('./data/' + mac + '.bin','./data/eeprom.bin')
print("Создан дубликат EEPROM, вносятся MAC адреса")
print ("")

eeprom = open('./data/eeprom.bin', 'rb+')	
mac = bytes.fromhex(mac)
eeprom.seek(4)
eeprom.write(mac)
eeprom.seek(28)
eeprom.write(mac)
eeprom.close()

print("Редактирование EEPROM завершено, ждём загрузки Breed")
print ("")
telnet.close()

if __name__ == '__main__':
p = Process(target=tftp_server)
p.start()
main()
p.terminate()
sys.exit()